import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import mongoose from 'mongoose'; // Added mongoose import
import connectDB from './config/db.js';
import userRoutes from './routes/userRoutes.js';
import { notFound, errorHandler } from './middleware/errorHandlers.js';
import locations from './data/locations.json' assert { type: "json" };

// Load environment variables first
dotenv.config();

// Create Express app
const app = express();

// Enhanced CORS configuration
const corsOptions = {
  origin: process.env.CORS_ORIGIN || 'http://localhost:5173', // Changed to CORS_ORIGIN
  methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE'],
  allowedHeaders: ['Content-Type', 'Authorization'],
  credentials: true,
  optionsSuccessStatus: 200 // For legacy browser support
};

// Database connection
connectDB();

// Middleware
app.use(cors(corsOptions));
app.use(express.json({ limit: '10kb' })); // Added payload limit
app.use(express.urlencoded({ extended: true, limit: '10kb' }));

// Request logging middleware (enhanced)
app.use((req, res, next) => {
  const start = Date.now();
  res.on('finish', () => {
    const duration = Date.now() - start;
    console.log(
      `${req.method} ${req.originalUrl} - ${res.statusCode} - ${duration}ms`
    );
  });
  next();
});

// API Information Route (enhanced)
app.get('/', (req, res) => {
  res.json({
    success: true,
    message: 'Globetrotter API',
    version: '1.0.0',
    environment: process.env.NODE_ENV || 'development',
    documentation: '/api-docs', // Consider adding API documentation endpoint
    endpoints: {
      users: {
        register: { method: 'POST', path: '/api/users/register' },
        getProfile: { method: 'GET', path: '/api/users/:username' },
        updateScore: { method: 'POST', path: '/api/users/:username/add-score' }
      }
    }
  });
});

// API Routes
app.use('/api/users', userRoutes);

// Serve a random location for the quiz
app.get('/api/random-location', (req, res) => {
  const random = locations[Math.floor(Math.random() * locations.length)];
  res.json(random);
});



// Health check endpoint
app.get('/health', (req, res) => {
  res.json({
    status: 'ok',
    dbState: mongoose.connection.readyState === 1 ? 'connected' : 'disconnected',
    timestamp: new Date().toISOString()
  });
});

// Error Handling Middleware (must be last)
app.use(notFound);
app.use(errorHandler);

// Server configuration
const PORT = process.env.PORT || 5000;
const server = app.listen(PORT, () => {
  console.log(`🚀 Server running in ${process.env.NODE_ENV || 'development'} mode`);
  console.log(`📡 Listening on port ${PORT}`);
});

// Handle process termination
const shutdown = (signal) => {
  console.log(`\n${signal} received: closing server...`);
  server.close(async () => {
    console.log('Server closed');
    await mongoose.connection.close();
    console.log('Database connection closed');
    process.exit(0);
  });
};

// Handle various termination signals
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGQUIT', () => shutdown('SIGQUIT'));

// Handle uncaught exceptions and rejections
process.on('uncaughtException', (err) => {
  console.error('Uncaught Exception:', err);
  shutdown('uncaughtException');
});

process.on('unhandledRejection', (err) => {
  console.error('Unhandled Rejection:', err);
  shutdown('unhandledRejection');
});

// Mongoose configuration
mongoose.set('strictQuery', false);
mongoose.connection.on('connected', () => {
  console.log('✅ MongoDB connection established');
});

mongoose.connection.on('disconnected', () => {
  console.log('❌ MongoDB connection lost');
});